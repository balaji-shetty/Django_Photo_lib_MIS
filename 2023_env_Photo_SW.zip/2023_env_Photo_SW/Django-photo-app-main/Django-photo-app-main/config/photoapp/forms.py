'''Photo app Forms'''
